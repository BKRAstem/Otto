# Issue Template

## Explain the problem:

*Is it a code issue? - make sure you are using the right libraries and Mblock or Arduino software, please post a screenshot.

*Is it an electronic issue? - please post a complementary picture.

*Is it a 3D print issue? - In the case of 3D print improvement please post in thingiverse.

If solved please share the solution.

Thanks #Ottobuilder
  
